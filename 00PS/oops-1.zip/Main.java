/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
    
    public static void main(String[] args) {
        Dharani();
        Dharshini();
        Nivo();
        Ani();
         }
    
    public static void Dharani() {
        System.out.println( "Dharani: she is very innocent");
       
    }
    public static void Dharshini() {
        System.out.println( "Dharshini: she is very badgirl");
       
    }
    public static void Nivo() {
        System.out.println( "Nivo: she is very caring");
       
    }
    public static void Ani() {
        System.out.println( "Ani: she is very Kind");
       
    }

}
