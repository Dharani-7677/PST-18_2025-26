/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void main(String[] args) {

        int a = 10;
        int b = 5;

        // Logical AND
        System.out.println(a > b && a > 0);   

        // Logical OR
        System.out.println(a < b || a > 0);   

        // Logical NOT
        System.out.println(!(a > b));  
    }
}
