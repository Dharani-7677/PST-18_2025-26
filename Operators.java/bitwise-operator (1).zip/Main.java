/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void main(String[] args) {

        int a = 5;   // 0101
        int b = 3;   // 0011

        System.out.println(a & b);   // AND
        System.out.println(a | b);   // OR
        System.out.println(a ^ b);   // XOR
        System.out.println(~a);      // NOT
        System.out.println(a << 1);  // Left shift
        System.out.println(a >> 1);  // Right shift
    }
}
