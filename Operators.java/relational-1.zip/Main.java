/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
    public static void main(String[] args) {

        int a = 10;
        int b = 10;

        if (a == b) {
            System.out.println("Both values are equal");
        } else {
            System.out.println("Values are not equal");
        }
    }
}
