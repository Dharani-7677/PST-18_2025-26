/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void main(String[] args) {

        int a = 5;

        System.out.println(+a);   // Unary plus
        System.out.println(-a);   // Unary minus

        a++;  // Increment
        System.out.println(a);  
        
        ++a;  // Increment
        System.out.println(a); 

        a--;  // Decrement
        System.out.println(a); 
         --a;  // Decrement
        System.out.println(a); 

       
    }
}
